import React, { useState, useEffect, useCallback } from 'react';
import {
  AssetMetrics,
  IndexComposition,
  MarketSummary,
  StrengthHistoryPoint,
  Timeframe,
  UserSettings,
} from './types';
import { Header } from './components/Header';
import { DashboardCards } from './components/DashboardCards';
import { InteractiveCharts } from './components/InteractiveCharts';
import { AssetsTable } from './components/AssetsTable';
import { AssetDetailModal } from './components/AssetDetailModal';
import { MarketIndexModal } from './components/MarketIndexModal';
import { SettingsModal } from './components/SettingsModal';
import { ImportPortfolioModal } from './components/ImportPortfolioModal';
import {
  DEFAULT_SCORE_WEIGHTS,
  DEFAULT_MULTIPERIOD_WEIGHTS,
} from './indicators/calculations';
import { AccessPage } from './components/AccessPage';
import {
  getStoredLicenseSession,
  clearLicenseSession,
  validateLicense,
  StoredLicenseSession,
  LicenseInput,
} from './utils/licenseValidator';

export function App() {
  const [assets, setAssets] = useState<AssetMetrics[]>([]);
  const [summary, setSummary] = useState<MarketSummary | null>(null);
  const [composition, setComposition] = useState<IndexComposition | null>(null);
  const [history, setHistory] = useState<StrengthHistoryPoint[]>([]);
  const [selectedTimeframe, setSelectedTimeframe] = useState<Timeframe | 'multi'>('1d');

  const [selectedAssetTicker, setSelectedAssetTicker] = useState<string | null>(null);
  const [selectedIndexSymbol, setSelectedIndexSymbol] = useState<'IBOV' | 'WINFUT' | null>(null);
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const saved = typeof window !== 'undefined' ? localStorage.getItem('farol_theme') : null;
    return saved === 'light' ? 'light' : 'dark';
  });

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // License Authentication State
  const [licenseSession, setLicenseSession] = useState<StoredLicenseSession | null>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      // Support ?autostart=1 for rapid automated testing
      if (params.get('autostart') === '1') {
        return {
          idCliente: '12345678901',
          mesValidade: 12,
          anoValidade: 2027,
          chaveAtivacao: '148149284877',
          idIndicador: 'FRPBJCVF',
          validadoEm: new Date().toISOString(),
        };
      }
    }
    const stored = getStoredLicenseSession();
    if (!stored) return null;
    const check = validateLicense(
      {
        idCliente: stored.idCliente,
        mesValidade: stored.mesValidade,
        anoValidade: stored.anoValidade,
        chaveAtivacao: stored.chaveAtivacao,
        idIndicador: stored.idIndicador,
      },
      new Date()
    );
    return check.isValid ? stored : null;
  });

  const handleAccessGranted = (input: LicenseInput) => {
    setLicenseSession({
      idCliente: input.idCliente,
      mesValidade: input.mesValidade,
      anoValidade: input.anoValidade,
      chaveAtivacao: input.chaveAtivacao,
      idIndicador: input.idIndicador,
      validadoEm: new Date().toISOString(),
    });
    showToast('Acesso Liberado! Indicador FRPBJCVF ativado com sucesso.');
  };

  const handleLogoutLicense = () => {
    clearLicenseSession();
    setLicenseSession(null);
  };

  const toggleTheme = () => {
    setTheme((prev) => {
      const next = prev === 'dark' ? 'light' : 'dark';
      if (typeof window !== 'undefined') {
        localStorage.setItem('farol_theme', next);
      }
      return next;
    });
  };

  const [settings, setSettings] = useState<UserSettings>({
    autoRefreshIntervalSeconds: 60,
    defaultTimeframe: 'multi',
    scoreWeights: DEFAULT_SCORE_WEIGHTS,
    multiperiodWeights: DEFAULT_MULTIPERIOD_WEIGHTS,
    slopePeriodN: 5,
    activeProvider: 'yahoo_free',
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Fetch full market data
  const fetchData = useCallback(async () => {
    try {
      const [assetsRes, summaryRes, compRes, histRes, settRes] = await Promise.all([
        fetch('/api/assets'),
        fetch('/api/market/summary'),
        fetch('/api/index/composition'),
        fetch('/api/history/strength'),
        fetch('/api/settings'),
      ]);

      const [assetsData, summaryData, compData, histData, settData] = await Promise.all([
        assetsRes.json(),
        summaryRes.json(),
        compRes.json(),
        histRes.json(),
        settRes.json(),
      ]);

      if (assetsData.success) setAssets(assetsData.data);
      if (summaryData.success) setSummary(summaryData.data);
      if (compData.success) setComposition(compData.data);
      if (histData.success) setHistory(histData.data);
      if (settData.success) setSettings(settData.data);
    } catch (err) {
      console.error('Erro ao carregar dados do Farol Traders:', err);
    }
  }, []);

  // Initial load
  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Auto-refresh timer
  useEffect(() => {
    if (settings.autoRefreshIntervalSeconds <= 0) return;

    const interval = setInterval(async () => {
      try {
        await fetch('/api/refresh', { method: 'POST' });
        await fetchData();
      } catch (err) {
        console.error('Falha no auto-refresh:', err);
      }
    }, settings.autoRefreshIntervalSeconds * 1000);

    return () => clearInterval(interval);
  }, [settings.autoRefreshIntervalSeconds, fetchData]);

  // Manual refresh handler
  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    try {
      const res = await fetch('/api/refresh', { method: 'POST' });
      const data = await res.json();
      await fetchData();
      showToast('Cotações e indicadores recalculados com sucesso.');
    } catch (err) {
      console.error('Erro ao atualizar manualmente:', err);
      showToast('Falha na atualização de mercado.');
    } finally {
      setIsRefreshing(false);
    }
  };

  // Export CSV handler
  const handleExportCSV = () => {
    window.location.href = '/api/export/csv';
    showToast('Planilha CSV gerada com sucesso.');
  };

  // Settings update handler
  const handleUpdateSettings = async (newSettings: Partial<UserSettings>) => {
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSettings),
      });
      const data = await res.json();
      if (data.success) {
        setSettings(data.data);
        await fetchData();
        showToast('Parâmetros salvos e métricas recalculadas.');
      }
    } catch (err) {
      console.error('Erro ao salvar configurações:', err);
    }
  };

  const selectedAsset = assets.find((a) => a.ticker === selectedAssetTicker) || null;

  // Se o acesso NÃO estiver liberado, renderiza a Página de Acesso
  if (!licenseSession) {
    return (
      <AccessPage
        onAccessGranted={handleAccessGranted}
        theme={theme}
        onToggleTheme={toggleTheme}
      />
    );
  }

  // Se AcessoLiberado entao abra a tela do indicador
  return (
    <div
      className={`min-h-screen flex flex-col font-sans transition-colors duration-200 ${
        theme === 'light' ? 'bg-slate-100 text-slate-900' : 'bg-[#030712] text-slate-100'
      }`}
    >
      {/* Header */}
      <Header
        summary={summary}
        onRefresh={handleManualRefresh}
        isRefreshing={isRefreshing}
        onExportCSV={handleExportCSV}
        onOpenImportModal={() => setIsImportOpen(true)}
        onOpenSettingsModal={() => setIsSettingsOpen(true)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        theme={theme}
        onToggleTheme={toggleTheme}
        onOpenIndexModal={(symbol) => setSelectedIndexSymbol(symbol)}
        licenseSession={licenseSession}
        onLogoutLicense={handleLogoutLicense}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-[1720px] w-full mx-auto px-3 sm:px-5 py-4">
        {/* KPI Cards & Market Overview */}
        <DashboardCards
          summary={summary}
          theme={theme}
          onOpenIndexModal={(symbol) => setSelectedIndexSymbol(symbol)}
        />

        {/* 6 Interactive Visual Charts */}
        <InteractiveCharts
          assets={assets}
          summary={summary}
          history={history}
          selectedTimeframe={selectedTimeframe}
          onSelectAsset={(ticker) => setSelectedAssetTicker(ticker)}
        />

        {/* Assets & Weight Table */}
        <AssetsTable
          assets={assets}
          selectedTimeframe={selectedTimeframe}
          onSelectTimeframe={setSelectedTimeframe}
          onSelectAsset={(ticker) => setSelectedAssetTicker(ticker)}
        />
      </main>

      {/* Footer */}
      <footer
        className={`border-t py-3 px-5 text-center text-xs mt-8 transition-colors ${
          theme === 'light'
            ? 'bg-white border-slate-200 text-slate-500'
            : 'bg-[#0B132B]/80 border-slate-800/80 text-slate-400'
        }`}
      >
        <div className="max-w-[1720px] mx-auto flex flex-wrap items-center justify-between gap-2">
          <span>
            Farol Traders — Terminal de Inteligência Quantitativa • Baseada na Carteira Vigente do Ibovespa e Contratos WINFUT
          </span>
          <span className="text-[11px] text-slate-500">
            Fuso horário oficial: America/Sao_Paulo (BRT) • B3 BMF
          </span>
        </div>
      </footer>

      {/* Modal: Interactive Index Candlestick Chart (IBOV or WINFUT) */}
      {selectedIndexSymbol && (
        <MarketIndexModal
          symbol={selectedIndexSymbol}
          theme={theme}
          onClose={() => setSelectedIndexSymbol(null)}
        />
      )}

      {/* Modal: Individual Asset Analysis */}
      {selectedAssetTicker && (
        <AssetDetailModal
          asset={selectedAsset}
          summary={summary}
          onClose={() => setSelectedAssetTicker(null)}
        />
      )}

      {/* Modal: Settings & Weights */}
      {isSettingsOpen && (
        <SettingsModal
          settings={settings}
          onSave={handleUpdateSettings}
          onClose={() => setIsSettingsOpen(false)}
        />
      )}

      {/* Modal: Import Portfolio CSV */}
      {isImportOpen && (
        <ImportPortfolioModal
          currentComposition={composition}
          onImportSuccess={(msg) => {
            showToast(msg);
            fetchData();
          }}
          onClose={() => setIsImportOpen(false)}
        />
      )}

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 border border-amber-500/50 text-slate-100 text-xs font-semibold px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 animate-bounce">
          <span className="w-2 h-2 rounded-full bg-amber-400" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );

}

export default App;
